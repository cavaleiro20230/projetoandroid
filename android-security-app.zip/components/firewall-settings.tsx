"use client"

import { useState } from "react"
import { Globe, Shield, AlertTriangle } from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function FirewallSettings() {
  const [blockedApps, setBlockedApps] = useState([
    { id: 1, name: "Social Media App", icon: "🌐", blocked: true, risk: "medium" },
    { id: 2, name: "Game Center", icon: "🎮", blocked: false, risk: "low" },
    { id: 3, name: "Photo Editor Pro", icon: "📷", blocked: true, risk: "high" },
    { id: 4, name: "Weather Forecast", icon: "🌤️", blocked: false, risk: "low" },
    { id: 5, name: "Unknown App", icon: "❓", blocked: true, risk: "high" },
  ])

  const toggleAppBlock = (id: number) => {
    setBlockedApps(blockedApps.map((app) => (app.id === id ? { ...app, blocked: !app.blocked } : app)))
  }

  return (
    <div className="grid gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Firewall Protection</CardTitle>
          <CardDescription>Control network access for all applications</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                <div>
                  <p className="font-medium">Advanced Firewall Protection</p>
                  <p className="text-sm text-muted-foreground">Block malicious connections and intrusions</p>
                </div>
              </div>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-primary" />
                <div>
                  <p className="font-medium">Internet Access Control</p>
                  <p className="text-sm text-muted-foreground">Manage which apps can access the internet</p>
                </div>
              </div>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-primary" />
                <div>
                  <p className="font-medium">Suspicious Traffic Alerts</p>
                  <p className="text-sm text-muted-foreground">Get notified about unusual network activity</p>
                </div>
              </div>
              <Switch defaultChecked />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Application Control</CardTitle>
          <CardDescription>Manage internet access for individual apps</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[300px] pr-4">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Application</TableHead>
                  <TableHead>Risk Level</TableHead>
                  <TableHead className="text-right">Block Internet</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {blockedApps.map((app) => (
                  <TableRow key={app.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{app.icon}</span>
                        <span>{app.name}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={app.risk === "high" ? "destructive" : app.risk === "medium" ? "warning" : "outline"}
                      >
                        {app.risk.charAt(0).toUpperCase() + app.risk.slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Switch checked={app.blocked} onCheckedChange={() => toggleAppBlock(app.id)} />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  )
}

