"use client"

import { useState } from "react"
import { Shield, ShieldCheck, ShieldAlert, Wifi, FileSearch, Settings, Menu } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import FirewallSettings from "@/components/firewall-settings"
import MalwareScanner from "@/components/malware-scanner"
import SecurityLogs from "@/components/security-logs"

export default function SecurityDashboard() {
  const [securityScore, setSecurityScore] = useState(85)
  const [firewallEnabled, setFirewallEnabled] = useState(true)
  const [realTimeProtection, setRealTimeProtection] = useState(true)
  const [autoScan, setAutoScan] = useState(true)

  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-10 bg-white dark:bg-slate-900 border-b">
        <div className="container flex h-16 items-center px-4">
          <div className="flex items-center gap-2 font-semibold">
            <Shield className="h-6 w-6 text-primary" />
            <span>Android Security Firewall</span>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Button variant="ghost" size="icon">
              <Settings className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>
      <div className="container flex-1 px-4 py-6 md:py-8">
        <div className="grid gap-6">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle>Security Status</CardTitle>
                <div className="flex items-center gap-1 text-sm">
                  {securityScore > 70 ? (
                    <ShieldCheck className="h-5 w-5 text-green-500" />
                  ) : (
                    <ShieldAlert className="h-5 w-5 text-red-500" />
                  )}
                  <span className={securityScore > 70 ? "text-green-500" : "text-red-500"}>
                    {securityScore > 70 ? "Protected" : "At Risk"}
                  </span>
                </div>
              </div>
              <CardDescription>Your device security overview</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col gap-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Security Score</span>
                    <span className="text-sm font-medium">{securityScore}%</span>
                  </div>
                  <Progress value={securityScore} className="h-2" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="border-green-100 dark:border-green-900">
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className="bg-green-100 dark:bg-green-900/30 p-2 rounded-full">
                        <Wifi className="h-5 w-5 text-green-600 dark:text-green-400" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Firewall</p>
                        <p className="text-xs text-muted-foreground">Active protection</p>
                      </div>
                      <Switch className="ml-auto" checked={firewallEnabled} onCheckedChange={setFirewallEnabled} />
                    </CardContent>
                  </Card>
                  <Card className="border-blue-100 dark:border-blue-900">
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className="bg-blue-100 dark:bg-blue-900/30 p-2 rounded-full">
                        <Shield className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Real-time</p>
                        <p className="text-xs text-muted-foreground">Threat detection</p>
                      </div>
                      <Switch
                        className="ml-auto"
                        checked={realTimeProtection}
                        onCheckedChange={setRealTimeProtection}
                      />
                    </CardContent>
                  </Card>
                  <Card className="border-purple-100 dark:border-purple-900">
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className="bg-purple-100 dark:bg-purple-900/30 p-2 rounded-full">
                        <FileSearch className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Auto Scan</p>
                        <p className="text-xs text-muted-foreground">Daily checks</p>
                      </div>
                      <Switch className="ml-auto" checked={autoScan} onCheckedChange={setAutoScan} />
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="firewall">
            <TabsList className="grid grid-cols-3">
              <TabsTrigger value="firewall">Firewall</TabsTrigger>
              <TabsTrigger value="scanner">Malware Scanner</TabsTrigger>
              <TabsTrigger value="logs">Security Logs</TabsTrigger>
            </TabsList>
            <TabsContent value="firewall" className="mt-4">
              <FirewallSettings />
            </TabsContent>
            <TabsContent value="scanner" className="mt-4">
              <MalwareScanner />
            </TabsContent>
            <TabsContent value="logs" className="mt-4">
              <SecurityLogs />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

