"use client"

import { useState } from "react"
import { Shield, Info, Wifi, FileSearch, Clock } from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function SecurityLogs() {
  const [filter, setFilter] = useState("all")

  const logs = [
    {
      id: 1,
      type: "firewall",
      title: "Connection blocked",
      description: "Blocked suspicious connection from unknown source",
      time: "Today, 15:42",
      severity: "high",
    },
    {
      id: 2,
      type: "scan",
      title: "Scan completed",
      description: "Full system scan completed with 2 threats detected",
      time: "Today, 14:30",
      severity: "medium",
    },
    {
      id: 3,
      type: "firewall",
      title: "App blocked",
      description: "Blocked 'Unknown App' from accessing the internet",
      time: "Today, 12:15",
      severity: "medium",
    },
    {
      id: 4,
      type: "system",
      title: "Protection enabled",
      description: "Real-time protection service started",
      time: "Today, 09:00",
      severity: "info",
    },
    {
      id: 5,
      type: "scan",
      title: "Threat removed",
      description: "Successfully removed Trojan.AndroidOS.Agent.abc",
      time: "Yesterday, 18:22",
      severity: "high",
    },
    {
      id: 6,
      type: "firewall",
      title: "Connection blocked",
      description: "Blocked connection to known malicious server",
      time: "Yesterday, 16:45",
      severity: "high",
    },
    {
      id: 7,
      type: "system",
      title: "Update installed",
      description: "Security definitions updated to version 2.14.5",
      time: "Yesterday, 10:30",
      severity: "info",
    },
  ]

  const filteredLogs = filter === "all" ? logs : logs.filter((log) => log.type === filter)

  const getIcon = (type: string) => {
    switch (type) {
      case "firewall":
        return <Wifi className="h-5 w-5" />
      case "scan":
        return <FileSearch className="h-5 w-5" />
      case "system":
        return <Shield className="h-5 w-5" />
      default:
        return <Info className="h-5 w-5" />
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Security Logs</CardTitle>
          <CardDescription>Recent security events and alerts</CardDescription>
        </div>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter by type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Events</SelectItem>
            <SelectItem value="firewall">Firewall</SelectItem>
            <SelectItem value="scan">Scans</SelectItem>
            <SelectItem value="system">System</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px] pr-4">
          {filteredLogs.map((log) => (
            <div key={log.id} className="mb-4">
              <div className="flex items-start gap-3">
                <div
                  className={
                    log.severity === "high"
                      ? "text-red-500"
                      : log.severity === "medium"
                        ? "text-amber-500"
                        : "text-blue-500"
                  }
                >
                  {getIcon(log.type)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <p className="font-medium">{log.title}</p>
                    <div className="flex items-center gap-2">
                      <Badge
                        variant={
                          log.severity === "high" ? "destructive" : log.severity === "medium" ? "warning" : "outline"
                        }
                      >
                        {log.severity.charAt(0).toUpperCase() + log.severity.slice(1)}
                      </Badge>
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {log.time}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">{log.description}</p>
                </div>
              </div>
              <Separator className="my-3" />
            </div>
          ))}
        </ScrollArea>
        <div className="flex justify-center mt-4">
          <Button variant="outline">Export Logs</Button>
        </div>
      </CardContent>
    </Card>
  )
}

